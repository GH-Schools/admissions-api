module.exports = {
  uuidV4Pattern: /[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-([A-Fa-f0-9]+$)/g,
}